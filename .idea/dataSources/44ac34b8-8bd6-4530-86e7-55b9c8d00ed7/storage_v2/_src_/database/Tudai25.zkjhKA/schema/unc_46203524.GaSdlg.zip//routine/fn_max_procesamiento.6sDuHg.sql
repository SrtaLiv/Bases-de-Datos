create function fn_max_procesamiento() returns trigger
    language plpgsql
as
$$
    declare cantProcesamientos int;

    BEGIN
        SELECT count(*) INTO cantProcesamientos
        FROM unc_46203524.p5p2e4_procesamiento
        WHERE id_imagen = new.id_imagen;
        -- AND  = new.nro_secuencia;

        IF cantProcesamientos > 4 THEN
            RAISE EXCEPTION 'LA % NO PUEDE TENER VINCULADO MAS DE 5 PROCESAMIENTOS, TIENE %', NEW.id_imagen, cantProcesamientos;
        end if;
        RETURN NEW;
    END;
$$;

alter function fn_max_procesamiento() owner to unc_46203524;

