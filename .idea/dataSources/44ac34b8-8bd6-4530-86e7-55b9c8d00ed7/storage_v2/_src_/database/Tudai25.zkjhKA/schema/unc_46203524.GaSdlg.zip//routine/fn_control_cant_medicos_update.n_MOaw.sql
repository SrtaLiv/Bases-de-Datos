create function fn_control_cant_medicos_update() returns trigger
    language plpgsql
as
$$
BEGIN
    if(exists(
        SELECT 1
        where cod_centro = new.cod_centro
        GROUP BY tipo_especialidad, cod_especialidad
        having count(*) > 1
    )) THEN
        RAISE EXCEPTION 'HAY MUCHOS MEDICOS POR ESPECIALIDAD EN EL % %', NEW.COD_CENTRO, NEW.NOMBRE;
    END IF;
    RETURN NEW;
END;
$$;

alter function fn_control_cant_medicos_update() owner to unc_46203524;

