create function fn_max_autores() returns trigger
    language plpgsql
as
$$
    declare nac P5P2E3_ARTICULO.NACIONALIDAD%type;
    declare cant integer;
BEGIN
    -- PRIMER INTENTO
    -- ❌ No se pueden usar dos INTO en una sola consulta.
    -- ✅ Debés hacer dos consultas separadas: (GRACIAS CHAT!!)
    --SELECT count(c.id_articulo) INTO cant
    --FROM unc_46203524.p5p2e3_contiene c
    --JOIN unc_46203524.p5p2e3_articulo a
    --ON c.id_articulo = a.id_articulo
    --AND a.nacionalidad INTO autor;

    -- SEGUNDO INTENTO:
    --  🔴 Esto devolverá múltiples filas (una por artículo),
    --  y INTO cant espera una sola fila. Resultado: error en tiempo de ejecución (“more than one row returned”).
    --SELECT count(*) INTO cant
    --FROM unc_46203524.p5p2e3_contiene
    --GROUP BY p5p2e3_contiene.id_articulo;

    --🔴 Esto también puede devolver muchas filas (todos los autores argentinos),
    -- y otra vez falla por la misma razón.
    --SELECT nacionalidad INTO nacionalidad
    --FROM unc_46203524.p5p2e3_articulo
    --WHERE nacionalidad = 'Argentina';

    -- CORRECTO,
    -- ESTO DEVUELVE SOLO UNA FILA PORUQE FILTRAMOS POR EL ARTICULO MISMO, O SEA EL ARTIUCLO QUE SE
    -- ESTA TRATANDO DE INSERTAR

    --NEW es una fila virtual que existe solo dentro del trigger y contiene los datos que
    -- se están intentando insertar (o los nuevos valores en un UPDATE).

    -- Contar cuántas palabras clave tiene el artículo
    SELECT COUNT(*) INTO cant
    FROM unc_46203524.p5p2e3_contiene
    WHERE id_articulo = NEW.id_articulo;

    -- Obtener la nacionalidad del autor del artículo
    SELECT nacionalidad INTO nac
    FROM unc_46203524.p5p2e3_articulo
    WHERE id_articulo = NEW.id_articulo;

    IF (nac <> 'Argentina' AND cant > 9)
     THEN raise exception 'no puede insertar mas de 10 palabras claves';

    ELSIF nac = 'Argentina' and cant > 14
        THEN raise exception 'no puede insertar mas de 15 palabras claves';
    END IF;

RETURN NEW;
end;
    $$;

alter function fn_max_autores() owner to unc_46203524;

