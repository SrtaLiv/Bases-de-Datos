create function fn_actualizar_estadisticas() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Limpiar tabla estadística
    DELETE FROM estadistica;

    -- Volver a cargar los datos actualizados
    INSERT INTO estadistica (genero, total_peliculas, cantidad_idiomas)
    SELECT genero, COUNT(*) AS total_peliculas, COUNT(DISTINCT idioma) AS cantidad_idiomas
    FROM pelicula
    GROUP BY genero;

    RETURN NULL; -- Porque es AFTER STATEMENT
END;
$$;

alter function fn_actualizar_estadisticas() owner to unc_46203524;

