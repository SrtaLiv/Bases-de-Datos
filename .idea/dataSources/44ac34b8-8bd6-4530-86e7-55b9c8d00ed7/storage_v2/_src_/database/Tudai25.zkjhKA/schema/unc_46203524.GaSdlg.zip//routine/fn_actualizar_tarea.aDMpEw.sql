create function fn_actualizar_tarea() returns trigger
    language plpgsql
as
$$
    DECLARE
    operacion varchar;
registro varchar;
BEGIN
   IF tg_op = 'INSERT' THEN
       operacion := 'INSERT';
       registro := NEW.id_tarea;
    ELSIF tg_op = 'UPDATE' THEN
        operacion := 'UPDATE';
        registro := NEW.id_tarea;
   ELSIF TG_OP = 'DELETE' THEN
       operacion := 'DELETE';
       registro := OLD.id_tarea;
   end if;

   INSERT INTO unc_46203524.his_tarea(nro_registro, fecha, operacion, usuario)
   VALUES (registro, CURRENT_DATE, operacion, SESSION_USER);

   RETURN NULL;
end;
    $$;

alter function fn_actualizar_tarea() owner to unc_46203524;

